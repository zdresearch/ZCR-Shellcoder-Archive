#!/usr/bin/env python
'''
ZCR Shellcoder

ZeroDay Cyber Research
Z3r0D4y.Com
Ali Razmjoo
'''

def process(type,shellcode):
	if type == 'none':
		from encoder.none import start
		return start(shellcode)
	'''
	if type == 'none':
		
	if type == 'none':
		
	if type == 'none':
		
	if type == 'none':
		
	if type == 'none':
		
	if type == 'none':
		
	if type == 'none':
		
	if type == 'none':
		
	if type == 'none':
		
	if type == 'none':
		
	if type == 'none':
		
	if type == 'none':'''
		
