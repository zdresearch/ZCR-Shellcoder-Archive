#!/usr/bin/env python
'''
ZCR Shellcoder

ZeroDay Cyber Research
Z3r0D4y.Com
Ali Razmjoo
'''
def run(file_to_perm,perm_num):
	perm_num = "0x%x" % int(perm_num, 8)
	print perm_num
	
