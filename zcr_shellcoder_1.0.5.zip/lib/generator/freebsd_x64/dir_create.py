#!/usr/bin/env python
'''
ZCR Shellcoder

ZeroDay Cyber Research
Z3r0D4y.Com
Ali Razmjoo
'''
def run(dirname):
	print 'This feature is not active yet for this operation system !\nWait for updates , Thanks.\n'