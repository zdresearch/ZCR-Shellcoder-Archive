OWASP ZSC
=========

***THIS SOFTWARE CREATED TO CHALLENGE THE ANTIVIRUSES, RESEARCH TO DEFENDING NEW ENCRYPTION METHODS AND PROTECT SENSITIVE OPENSOURCE FILES WHICH ARE INCLUDING IMPORTANT DATA, CONTRIBUTORS AND OWASP FOUNDATION WILL NOT RESPONSIBLE FOR ANY ILLEGAL USAGES OR PURPOSES.***


OWASP ZSC is an open source software in python language which lets you generate customized shellcodes and convert scripts to an obfuscate script. This software can be run on Windows/Linux/OSX with python.

 * OWASP Page: https://www.owasp.org/index.php/OWASP_ZSC_Tool_Project
 * Documents: https://github.com/Ali-Razmjoo/OWASP-ZSC/tree/master/doc
 * Home: http://zsc.z3r0d4y.com/
 * Features: http://zsc.z3r0d4y.com/table.html
 * Github: https://github.com/Ali-Razmjoo/OWASP-ZSC
 * Archive: https://github.com/Ali-Razmjoo/ZCR-Shellcoder-Archive
 * About Author: http://www.z3r0d4y.com/p/about.html
 * Mailing List: https://lists.owasp.org/mailman/listinfo/owasp-zsc-tool-project

![screenshot](http://zsc.z3r0d4y.com/images/Snapshot_2015-07-26_191951.png)

#### For more information read the documents files in main directory or visit home page.
