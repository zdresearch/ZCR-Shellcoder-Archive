Changes
-------
version 1.0.9: Reboot
---------------------

 * add shell-storm api
 * fixed bug
 * change structre
 * add user friendly interface 
 * add opensource language obfuscator

version 1.0.8: F[ed]T
---------------------

 * Compatible With Windows [Linux,OSX,Windows]
 * Compatible with Python3 [Python 2.x,Python 3.x]
 * fixed add_random encoding in write() [linux_x86]
 * fixed add_yourvalue encoding in write() [linux_x86]
 * fixed sub_random encoding in write() [linux_x86]
 * fixed sub_yourvalue encoding in write() [linux_x86]
 * fixed xor_random encoding in write() [linux_x86]
 * fixed xor_yourvalue encoding in write() [linux_x86]
 * fixed dec encoding in write() [linux_x86]
 * fixed dec_timesyouwant encoding in write() [linux_x86]
 * fixed inc encoding in write() [linux_x86]
 * fixed inc_timesyouwant encoding in write() [linux_x86]
 * fixed mix_all encoding in write() [linux_x86]
 * fixed sub_random encoding in chmod() [linux_x86]
 * fix system() module in [linux_x86]
 * fix xor_random,add_random,sub_random in chmod() [linux_x86]

version 1.0.7.1: FT
-------------------


 * Optimized Core and Removed some required softwares
 * Compatible with OSX [tested on: OS X Yosemite 10.10.4] and Fixed Linux base bugs [tested on: Debian 7.8,Centos 6.7,OpenSUSE 13.2]
 * fixed some encoding modules



version 1.0.7: FT
-----------------


 * add xor_yourvalue encoding in exec() [linux_x86]
 * add add_yourvalue encoding in exec() [linux_x86]
 * add sub_yourvalue encoding in exec() [linux_x86]
 * add inc encoding in exec() [linux_x86]
 * add inc_timesyouwant encoding in exec() [linux_x86]
 * add dec encoding in exec() [linux_x86]
 * add dec_timesyouwant encoding in exec() [linux_x86]
 * add mic_all encoding in exec() [linux_x86]
 * add xor_yourvalue encoding in write() [linux_x86]
 * add add_yourvalue encoding in write() [linux_x86]
 * add sub_yourvalue encoding in write() [linux_x86]
 * add inc encoding in write() [linux_x86]
 * add inc_timesyouwant encoding in write() [linux_x86]
 * add dec encoding in write() [linux_x86]
 * add dec_timesyouwant encoding in write() [linux_x86]
 * add mic_all encoding in write() [linux_x86]
 * fixed xor_random encoding in write() [linux_x86]
 * fixed add_random encoding in write() [linux_x86]
 * fixed sub_random encoding in write() [linux_x86]
 * fixed dec_timesyouwant encoding in file_create() [linux_x86]
 * fixed dec_timesyouwant encoding in dir_create() [linux_x86]
 * fixed dec_timesyouwant encoding in download() [linux_x86]
 * fixed dec_timesyouwant encoding in download_execute() [linux_x86]
 * fixed dec_timesyouwant encoding in script_executor() [linux_x86]
 * Optimized software engine and shellcode generators


version 1.0.6: B2018
--------------------


 * add mix_all encoding in chmod() [linux_x86]
 * add xor_random encoding in system() [linux_x86]
 * add xor_yourvalue encoding in system() [linux_x86]
 * add add_random encoding in system() [linux_x86]
 * add add_yourvalue encoding in system() [linux_x86]
 * add sub_random encoding in system() [linux_x86
 * add sub_yourvalue encoding in system() [linux_x86]
 * add inc encoding in system() [linux_x86]
 * add inc_timesyouwant encoding in system() [linux_x86
 * add dec encoding in system() [linux_x86]
 * add dec_timesyouwant encoding in system() [linux_x86]
 * add mix_all encoding in system() [linux_x86]
 * add xor_random encoding in file_create() [linux_x86]
 * add xor_yourvalue encoding in file_create() [linux_x86]
 * add add_random encoding in file_create() [linux_x86]
 * add add_yourvalue encoding in file_create() [linux_x86]
 * add sub_random encoding in file_create() [linux_x86
 * add sub_yourvalue encoding in file_create() [linux_x86]
 * add inc encoding in file_create() [linux_x86]
 * add inc_timesyouwant encoding in file_create() [linux_x86
 * add dec encoding in file_create() [linux_x86]
 * add dec_timesyouwant encoding in file_create() [linux_x86]
 * add mix_all encoding in file_create() [linux_x86]
 * add xor_random encoding in dir_create() [linux_x86]
 * add xor_yourvalue encoding in dir_create() [linux_x86]
 * add add_random encoding in dir_create() [linux_x86]
 * add add_yourvalue encoding in dir_create() [linux_x86]
 * add sub_random encoding in dir_create() [linux_x86
 * add sub_yourvalue encoding in dir_create() [linux_x86]
 * add inc encoding in dir_create() [linux_x86]
 * add inc_timesyouwant encoding in dir_create() [linux_x86
 * add dec encoding in dir_create() [linux_x86]
 * add dec_timesyouwant encoding in dir_create() [linux_x86]
 * add mix_all encoding in dir_create() [linux_x86]
 * add xor_random encoding in download() [linux_x86]
 * add xor_yourvalue encoding in download() [linux_x86]
 * add add_random encoding in download() [linux_x86]
 * add add_yourvalue encoding in download() [linux_x86]
 * add sub_random encoding in download() [linux_x86
 * add sub_yourvalue encoding in download() [linux_x86]
 * add inc encoding in download() [linux_x86]
 * add inc_timesyouwant encoding in download() [linux_x86
 * add dec encoding in download() [linux_x86]
 * add dec_timesyouwant encoding in download() [linux_x86]
 * add mix_all encoding in download() [linux_x86]
 * add xor_random encoding in download_execute() [linux_x86]
 * add xor_yourvalue encoding in download_execute() [linux_x86]
 * add add_random encoding in download_execute() [linux_x86]
 * add add_yourvalue encoding in download_execute() [linux_x86]
 * add sub_random encoding in download_execute() [linux_x86
 * add sub_yourvalue encoding in download_execute() [linux_x86]
 * add inc encoding in download_execute() [linux_x86]
 * add inc_timesyouwant encoding in download_execute() [linux_x86
 * add dec encoding in download_execute() [linux_x86]
 * add dec_timesyouwant encoding in download_execute() [linux_x86]
 * add mix_all encoding in download_execute() [linux_x86]
 * add xor_random encoding in system() [linux_x86]
 * add xor_yourvalue encoding in system() [linux_x86]
 * add add_random encoding in system() [linux_x86]
 * add add_yourvalue encoding in system() [linux_x86]
 * add sub_random encoding in system() [linux_x86
 * add sub_yourvalue encoding in system() [linux_x86]
 * add inc encoding in system() [linux_x86]
 * add inc_timesyouwant encoding in system() [linux_x86
 * add dec encoding in system() [linux_x86]
 * add dec_timesyouwant encoding in system() [linux_x86]
 * add mix_all encoding in system() [linux_x86]
 * add xor_random encoding in script_executor() [linux_x86]
 * add xor_yourvalue encoding in script_executor() [linux_x86]
 * add add_random encoding in script_executor() [linux_x86]
 * add add_yourvalue encoding in script_executor() [linux_x86]
 * add sub_random encoding in script_executor() [linux_x86
 * add sub_yourvalue encoding in script_executor() [linux_x86]
 * add inc encoding in script_executor() [linux_x86]
 * add inc_timesyouwant encoding in script_executor() [linux_x86
 * add dec encoding in script_executor() [linux_x86]
 * add dec_timesyouwant encoding in script_executor() [linux_x86]
 * add mix_all encoding in script_executor() [linux_x86]
 * add add_random encoding in write() [linux_x86]
 * add xor_random encoding in write() [linux_x86]
 * add sub_random encoding in write() [linux_x86]
 * add xor_random encoding in exec() [linux_x86]
 * add sub_random encoding in exec() [linux_x86
 * add add_random encoding in exec() [linux_x86]
 * fixed bug in system() when len(command) is less than 5
 * fixed bug in encode module add_random chmod() [linux_x86]



version 1.0.5.2: S
------------------
 * Project name changed To OWASP ZSC + Signature
 * installing directory changed to /usr/share/owasp_zsc

version 1.0.5.1: CaMo
---------------------
 * upgrade "-wizard" switch
 * add length calculator for output
 * add filename writer in gcc commandline in output file
 * fixed bug in encoding module not available.
 * fixed bug in os module not available

version 1.0.5: CaMo
-------------------
 * add "-wizard" switch
 * add installer "use 'zsc' commandline in terminal after installed"
 * add uninstaller
 * This Software just could be run on linux since this version
 * change output to .c file and automated shellcode generating
 * add color output for terminal
 * etc ...

version 1.0.4.1: Infinity
-------------------------
 * bug fix reported by user in executing on linux , color function

version 1.0.4: Infinity
-----------------------
 * add inc encoding chmod() [linux_x86]
 * add inc_timesyouwant chmod() [linux_x86]
 * add dec encoding chmod() [linux_x86]
 * add dec_timesyouwant chmod() [linux_x86]
 * add features table inside "features_table.html"
 * add -about to menu for developers name and etc
 * add color output for windows cmd
 * fixed permission number calculating in chmod() [linux_x86]
 * software's signature changes

version 1.0.3: AWAKE
--------------------
 * add xor_random encoding chmod() [linux_x86]
 * add xor_yourvalue encoding chmod() [linux_x86]
 * add add_random encoding chmod() [linux_x86]
 * add add_yourvalue encoding chmod() [linux_x86]
 * add sub_random encoding chmod() [linux_x86]
 * add sub_yourvalue encoding chmod() [linux_x86]
 * fixed shellcode encode type checking

version 1.0.2: SKIP
-------------------
 * [linux_x86 modules completed]
 * add script_executor() [linux - using command execution]
 * add download_execute() [linux_x86 - using command execution (wget)]
 * add download() [linux_x86 - using command execution (wget)]
 * add dir_create() [linux_x86 using command execution]
 * add file_create() [linux_x86 using command execution]
 * add encodes file for next version released

version 1.0.1: BOILING_POINT
----------------------------
 * add system() [linux_x86 command execute]
 * fixed chmod filename 1/4 char length [linux_x86]
 * fixed exec filename 1/4 char length [linux_x86]
 * fixed write filename 1/4 length [linux_x86]
 * fixed write content 1/4 length [linux_x86]
 * fixed write length calculator [linux_x86]
 * and fixed some other bugs in coding [core]

version 1.0.0: ASIIN_BLUE_RUBY
------------------------------

 * add chmod() [linux_x86] -> chmod('/path/file','perm_num')
 * add write() [linux_x86] -> write('/path/file','content')
 * add exec() [linux_x86]  -> exec('/path/file')
 * add encode [none - all os]

