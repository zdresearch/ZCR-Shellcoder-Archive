OWASP ZSC
=========

OWASP ZCR Shellcoder is an open source software in python language which lets you 
generate customized  shellcodes for listed operation systems. This software 
can be run on Windows/Linux&Unix/OSX and others OS under python [2.x and 3.x compatible].

 * OWASP Page: https://www.owasp.org/index.php/OWASP_ZSC_Tool_Project
 * Home: http://zsc.z3r0d4y.com/
 * Features: http://zsc.z3r0d4y.com/table.html
 * Github: https://github.com/Ali-Razmjoo/OWASP-ZSC
 * Archive: https://github.com/Ali-Razmjoo/ZCR-Shellcoder-Archive
 * About Author: http://www.z3r0d4y.com/p/about.html
 * Mailing List: https://lists.owasp.org/mailman/listinfo/owasp-zsc-tool-project

![screenshot](http://zsc.z3r0d4y.com/images/Snapshot_2015-07-26_191951.png)

For more information read the document files in main directory or visit home page.